
console.log("Notes AD loaded!");
